#!/usr/bin/env bash
# fixture script
set -e
echo ok
